from setuptools import setup

setup(
    name='python_programing',
    version='1.0.0',
    packages=['lesson_package', 'lesson_package.talk', 'lesson_package.tools'],
    license='Free',
    author='jsakai',
    author_email='',
    description='Sample package'
)
