from lesson_package.tools import utils


def sing():
    return '##fjiafiewafdafie'


def cry():
    return utils.say_twice('fjdsiafjdaofejwa')
